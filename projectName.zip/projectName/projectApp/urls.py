#now import the views.py file into this code
from . import views
from django.urls import path, include


# importing views from views..py
from .views import home_view
# from .views import formset_view
from django.contrib import admin
# from .views import modelformset_view
# from .views import geeks_view
# from .views import list_view
# from .views import GeeksList
# from .views import create_view
# from .views import detail_view
# from .views import update_view
# from .views import delete_view
# from myapp.views import MyView
# from .views import GeeksCreate
# from .views import GeeksList
# from .views import GeeksDetailView
# from .views import GeeksUpdateView
# from .views import GeeksDeleteView
# from .views import GeeksFormView



# urlpatterns=[
#   path('',views.index)
#   ]

# urlpatterns=[
#   path('',views.home_view)
#   ]
 
# urlpatterns = [
#     path('', home_view ),
# ]

urlpatterns = [
    path('admin/', admin.site.urls),
    # Enter the app name in following
    # syntax for this to work
     path('',home_view ),
    #  path('/projectApp', include("projectApp.urls")),
    #  path('', formset_view ),
    # path('', modelformset_view ),
    # path('', geeks_view),
    # path('', list_view),
    # path('', GeeksList.as_view()),
    # path('', create_view),
    # path('<id>', detail_view ),
    # path('<id>/update', update_view ),
    # path('<id>/delete', delete_view ),
    # path('about/', MyView.as_view()),
    # path('', GeeksCreate.as_view() ),
    # path('', GeeksList.as_view()),
    # <pk> is identification for id field,
    # slug can also be used
    # path('<pk>/', GeeksDetailView.as_view()),
    # path('<pk>/update', GeeksUpdateView.as_view()),
    # path('<pk>/delete/', GeeksDeleteView.as_view()),
    # path('', GeeksFormView.as_view()),
]
