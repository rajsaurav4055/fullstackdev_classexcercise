from django.contrib import admin
from .models import GeeksModel
# from .models import GeeksModel
# Register your models here.
admin.site.register(GeeksModel)

# from .models import Album, Song

# admin.site.register(Album)
# admin.site.register(Song)